import { Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";

export function ThemeToggle() {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const isDarkMode = document.documentElement.classList.contains("dark");
    setIsDark(isDarkMode);
  }, []);

  const toggleTheme = () => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.remove("dark");
      setIsDark(false);
    } else {
      root.classList.add("dark");
      setIsDark(true);
    }
  };

  return (
    <button
      onClick={toggleTheme}
      className="p-2 text-muted-foreground hover:text-primary hover:bg-primary/5 rounded-full transition-all relative overflow-hidden"
      aria-label="Toggle Theme"
    >
      <div className={`transition-transform duration-500 ${isDark ? "rotate-90 scale-0" : "rotate-0 scale-100"}`}>
        <Moon className="w-5 h-5 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
      </div>
      <div className={`transition-transform duration-500 ${isDark ? "rotate-0 scale-100" : "-rotate-90 scale-0"}`}>
        <Sun className="w-5 h-5 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
      </div>
      {/* Invisible placeholder to maintain size */}
      <Moon className="w-5 h-5 opacity-0" />
    </button>
  );
}

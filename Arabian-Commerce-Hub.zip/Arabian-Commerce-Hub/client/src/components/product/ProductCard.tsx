import { Link } from "wouter";
import { Heart, ShoppingCart } from "lucide-react";
import { type Product } from "@shared/schema";
import { formatPrice } from "@/lib/utils";
import { useCart } from "@/store/use-cart";
import { useToggleWishlist, useWishlist } from "@/hooks/use-wishlist";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const addItem = useCart(state => state.addItem);
  const { toggle } = useToggleWishlist();
  const { data: wishlist } = useWishlist();
  const { toast } = useToast();

  const isFav = wishlist?.some(item => item.productId === product.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addItem(product, 1);
    toast({ title: "تمت الإضافة للسلة", description: product.name });
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    toggle(product.id);
  };

  return (
    <Link href={`/product/${product.id}`} className="group block">
      <motion.div 
        whileHover={{ y: -5 }}
        className="bg-card rounded-3xl overflow-hidden border border-border/50 shadow-sm hover:shadow-xl hover:border-primary/20 transition-all duration-300"
      >
        <div className="relative aspect-[4/5] overflow-hidden bg-muted">
          {product.imageUrl ? (
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-secondary text-muted-foreground font-display text-xl">
              لا توجد صورة
            </div>
          )}
          
          {/* Badges */}
          {product.stock < 5 && product.stock > 0 && (
            <div className="absolute top-4 right-4 bg-destructive text-destructive-foreground px-3 py-1 rounded-full text-xs font-bold">
              توشك على النفاذ
            </div>
          )}

          {/* Action buttons overlay */}
          <div className="absolute top-4 left-4 flex flex-col gap-2 opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
            <button 
              onClick={handleWishlist}
              className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-md transition-colors ${isFav ? 'bg-primary text-primary-foreground' : 'bg-background/80 text-foreground hover:bg-primary hover:text-primary-foreground'}`}
            >
              <Heart className={`w-5 h-5 ${isFav ? 'fill-current' : ''}`} />
            </button>
          </div>

          <div className="absolute bottom-4 left-0 right-0 px-4 opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
            <button 
              onClick={handleAddToCart}
              className="w-full bg-primary/90 hover:bg-primary backdrop-blur-md text-primary-foreground py-3 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-primary/25"
            >
              <ShoppingCart className="w-5 h-5" />
              أضف للسلة
            </button>
          </div>
        </div>

        <div className="p-5">
          <div className="text-xs font-semibold text-primary mb-2">{product.category}</div>
          <h3 className="font-bold text-lg text-foreground mb-1 line-clamp-1 group-hover:text-primary transition-colors">{product.name}</h3>
          <p className="text-xl font-display font-bold text-foreground">{formatPrice(product.price)}</p>
        </div>
      </motion.div>
    </Link>
  );
}

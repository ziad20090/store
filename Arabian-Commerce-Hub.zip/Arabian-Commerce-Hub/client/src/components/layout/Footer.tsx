import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-card border-t border-border/50 mt-auto">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="font-display font-bold text-xl text-foreground">لوكس</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              متجرك الأول للأزياء العصرية والمنتجات الفاخرة. نقدم لك أفضل جودة بأفضل سعر.
            </p>
          </div>
          <div>
            <h4 className="font-bold text-foreground mb-4">روابط سريعة</h4>
            <ul className="space-y-2">
              <li><Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">الرئيسية</Link></li>
              <li><Link href="/shop" className="text-sm text-muted-foreground hover:text-primary transition-colors">المتجر</Link></li>
              <li><Link href="/categories" className="text-sm text-muted-foreground hover:text-primary transition-colors">التصنيفات</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-foreground mb-4">المساعدة</h4>
            <ul className="space-y-2">
              <li><Link href="/faq" className="text-sm text-muted-foreground hover:text-primary transition-colors">الأسئلة الشائعة</Link></li>
              <li><Link href="/shipping" className="text-sm text-muted-foreground hover:text-primary transition-colors">الشحن والتوصيل</Link></li>
              <li><Link href="/returns" className="text-sm text-muted-foreground hover:text-primary transition-colors">سياسة الإسترجاع</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-foreground mb-4">تواصل معنا</h4>
            <ul className="space-y-2">
              <li className="text-sm text-muted-foreground">support@lux.com</li>
              <li className="text-sm text-muted-foreground">+966 50 123 4567</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border/50 mt-12 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} لوكس. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  );
}

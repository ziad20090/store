import { Link, useLocation } from "wouter";
import { ShoppingBag, User, Heart, Menu, Search } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/store/use-cart";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { ThemeToggle } from "@/components/ui/ThemeToggle";

export function Navbar() {
  const { user, logout } = useAuth();
  const cartItems = useCart(state => state.items);
  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [_, setLocation] = useLocation();

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-background/80 backdrop-blur-xl border-b border-border/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          
          <div className="flex items-center gap-6">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-primary-foreground font-display font-bold text-xl group-hover:shadow-lg group-hover:shadow-primary/25 transition-all duration-300">
                L
              </div>
              <span className="font-display font-bold text-xl tracking-tight text-foreground hidden sm:block">لوكس</span>
            </Link>

            <nav className="hidden md:flex items-center gap-6 ms-6">
              <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">الرئيسية</Link>
              <Link href="/shop" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">المتجر</Link>
              <Link href="/categories" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">التصنيفات</Link>
            </nav>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
            <div className="hidden lg:flex relative mr-4 group">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
              <input 
                type="text" 
                placeholder="ابحث عن منتج..." 
                className="pl-4 pr-10 py-2 w-64 rounded-full bg-muted/50 border border-transparent focus:bg-background focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all duration-300 outline-none text-sm"
              />
            </div>

            <ThemeToggle />

            <Link href="/wishlist" className="p-2 text-muted-foreground hover:text-primary hover:bg-primary/5 rounded-full transition-all relative">
              <Heart className="w-5 h-5" />
            </Link>

            <Link href="/cart" className="p-2 text-muted-foreground hover:text-primary hover:bg-primary/5 rounded-full transition-all relative">
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <motion.span 
                  initial={{ scale: 0 }} 
                  animate={{ scale: 1 }} 
                  className="absolute top-0 right-0 w-4 h-4 bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center rounded-full shadow-sm"
                >
                  {cartCount}
                </motion.span>
              )}
            </Link>

            {user ? (
              <div className="relative group">
                <button className="flex items-center gap-2 p-2 text-muted-foreground hover:text-primary hover:bg-primary/5 rounded-full transition-all">
                  <User className="w-5 h-5" />
                </button>
                <div className="absolute top-full left-0 mt-2 w-48 bg-card rounded-2xl shadow-xl border border-border/50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 transform origin-top translate-y-2 group-hover:translate-y-0">
                  <div className="p-4 border-b border-border/50">
                    <p className="text-sm font-bold text-foreground truncate">{user.username}</p>
                    <p className="text-xs text-muted-foreground">{user.role === 'admin' ? 'مدير النظام' : 'عميل'}</p>
                  </div>
                  <div className="p-2 flex flex-col">
                    {user.role === 'admin' && (
                      <Link href="/admin" className="px-4 py-2 text-sm text-foreground hover:bg-muted rounded-xl transition-colors text-start">لوحة التحكم</Link>
                    )}
                    <Link href="/dashboard" className="px-4 py-2 text-sm text-foreground hover:bg-muted rounded-xl transition-colors text-start">طلباتي</Link>
                    <button onClick={handleLogout} className="px-4 py-2 text-sm text-destructive hover:bg-destructive/10 rounded-xl transition-colors text-start w-full">تسجيل الخروج</button>
                  </div>
                </div>
              </div>
            ) : (
              <Link href="/auth" className="px-5 py-2 text-sm font-medium bg-primary text-primary-foreground rounded-full hover:shadow-lg hover:shadow-primary/30 transition-all duration-300 hover:-translate-y-0.5">
                دخول
              </Link>
            )}

            <button 
              className="md:hidden p-2 text-muted-foreground"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden border-t border-border/50 bg-background overflow-hidden"
          >
            <nav className="flex flex-col p-4 space-y-4">
              <Link href="/" onClick={() => setIsMobileMenuOpen(false)} className="text-foreground font-medium">الرئيسية</Link>
              <Link href="/shop" onClick={() => setIsMobileMenuOpen(false)} className="text-foreground font-medium">المتجر</Link>
              <Link href="/categories" onClick={() => setIsMobileMenuOpen(false)} className="text-foreground font-medium">التصنيفات</Link>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

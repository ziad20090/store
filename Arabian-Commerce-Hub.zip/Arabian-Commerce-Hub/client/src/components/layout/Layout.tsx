import { ReactNode, useEffect } from "react";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import { useLocation } from "wouter";

export function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith("/admin");

  return (
    <div dir="rtl" className="min-h-screen flex flex-col bg-background">
      {!isAdminRoute && <Navbar />}
      <main className="flex-1 flex flex-col relative w-full">
        {children}
      </main>
      {!isAdminRoute && <Footer />}
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { type Product } from "@shared/schema";

interface AnalyticsResponse {
  totalSales: number;
  totalOrders: number;
  totalUsers: number;
  lowStockProducts: Product[];
}

export function useAnalytics() {
  return useQuery<AnalyticsResponse>({
    queryKey: ["/api/admin/analytics"],
    queryFn: async () => {
      const res = await fetch("/api/admin/analytics");
      if (!res.ok) throw new Error("Failed to fetch analytics");
      return res.json();
    },
  });
}

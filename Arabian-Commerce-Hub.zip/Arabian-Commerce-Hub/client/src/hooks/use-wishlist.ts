import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { type WishlistResponse } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "./use-auth";

export function useWishlist() {
  const { user } = useAuth();
  
  return useQuery<WishlistResponse>({
    queryKey: ["/api/wishlist"],
    queryFn: async () => {
      const res = await fetch("/api/wishlist");
      if (!res.ok) throw new Error("Failed to fetch wishlist");
      return res.json();
    },
    enabled: !!user,
  });
}

export function useToggleWishlist() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (productId: number) => {
      const res = await fetch("/api/wishlist/toggle", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId }),
      });
      if (!res.ok) throw new Error("Failed to toggle wishlist");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/wishlist"] });
      if (data.added) {
        toast({ title: "تمت الإضافة للمفضلة", duration: 2000 });
      } else {
        toast({ title: "تمت الإزالة من المفضلة", duration: 2000 });
      }
    },
    onError: () => toast({ title: "يرجى تسجيل الدخول أولاً", variant: "destructive" })
  });
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { type OrderResponse, type CreateOrderRequest } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useCart } from "@/store/use-cart";

export function useOrders() {
  return useQuery<OrderResponse[]>({
    queryKey: ["/api/orders"],
    queryFn: async () => {
      const res = await fetch("/api/orders");
      if (!res.ok) throw new Error("Failed to fetch orders");
      return res.json();
    },
  });
}

export function useAllOrders() {
  return useQuery<OrderResponse[]>({
    queryKey: ["/api/admin/orders"],
    queryFn: async () => {
      const res = await fetch("/api/admin/orders");
      if (!res.ok) throw new Error("Failed to fetch all orders");
      return res.json();
    },
  });
}

export function useCreateOrder() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const clearCart = useCart(state => state.clearCart);

  return useMutation({
    mutationFn: async (data: CreateOrderRequest) => {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to create order");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      clearCart();
      toast({ title: "تم استلام طلبك بنجاح!" });
    },
    onError: (err) => toast({ title: "حدث خطأ", description: err.message, variant: "destructive" })
  });
}

export function useUpdateOrderStatus() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const res = await fetch(`/api/orders/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error("Failed to update status");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      toast({ title: "تم تحديث حالة الطلب بنجاح" });
    },
    onError: () => toast({ title: "حدث خطأ", variant: "destructive" })
  });
}

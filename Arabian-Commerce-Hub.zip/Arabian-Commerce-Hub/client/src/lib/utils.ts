import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(cents: number) {
  return (cents / 100).toLocaleString('ar-SA', {
    style: 'currency',
    currency: 'SAR',
  });
}

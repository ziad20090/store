import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout/Layout";
import { useAuth } from "@/hooks/use-auth";

import Home from "@/pages/home";
import ProductsPage from "@/pages/products";
import ProductDetails from "@/pages/product-details";
import CartPage from "@/pages/cart";
import CheckoutPage from "@/pages/checkout";
import AuthPage from "@/pages/auth";
import DashboardPage from "@/pages/dashboard";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminProducts from "@/pages/admin/products";
import AdminOrders from "@/pages/admin/orders";
import AdminCoupons from "@/pages/admin/coupons";
import NotFound from "@/pages/not-found";

function AdminGuard({ component: Component }: { component: any }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) return null;
  
  if (!user || user.role !== 'admin') {
    setLocation("/");
    return null;
  }

  return (
    <div dir="rtl" className="min-h-screen bg-background text-foreground">
      <Component />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      {/* Admin Routes - Separate Layout handled in Guard */}
      <Route path="/admin">
        {() => <AdminGuard component={AdminDashboard} />}
      </Route>
      <Route path="/admin/products">
        {() => <AdminGuard component={AdminProducts} />}
      </Route>
      <Route path="/admin/orders">
        {() => <AdminGuard component={AdminOrders} />}
      </Route>
      <Route path="/admin/coupons">
        {() => <AdminGuard component={AdminCoupons} />}
      </Route>

      {/* Public / User Routes with Main Layout */}
      <Route path="*">
        <Layout>
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/shop" component={ProductsPage} />
            <Route path="/categories" component={ProductsPage} />
            <Route path="/product/:id" component={ProductDetails} />
            <Route path="/cart" component={CartPage} />
            <Route path="/checkout" component={CheckoutPage} />
            <Route path="/auth" component={AuthPage} />
            <Route path="/dashboard" component={DashboardPage} />
            <Route path="/wishlist" component={ProductsPage} /> {/* Simple fallback for now */}
            <Route component={NotFound} />
          </Switch>
        </Layout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

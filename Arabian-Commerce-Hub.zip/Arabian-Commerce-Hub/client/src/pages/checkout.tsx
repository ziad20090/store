import { useState } from "react";
import { useLocation } from "wouter";
import { useCart } from "@/store/use-cart";
import { formatPrice } from "@/lib/utils";
import { useValidateCoupon } from "@/hooks/use-coupons";
import { useCreateOrder } from "@/hooks/use-orders";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Ticket, Loader2 } from "lucide-react";

export default function CheckoutPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { items, getSubtotal } = useCart();
  const { toast } = useToast();

  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  
  const validateMutation = useValidateCoupon();
  const createOrderMutation = useCreateOrder();

  // Redirect if cart empty or not logged in
  if (!user) {
    setLocation("/auth");
    return null;
  }
  if (items.length === 0) {
    setLocation("/cart");
    return null;
  }

  const subtotal = getSubtotal();
  let discountAmount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.discountType === 'percent') {
      discountAmount = (subtotal * appliedCoupon.discountValue) / 100;
    } else {
      discountAmount = appliedCoupon.discountValue;
    }
  }
  const total = Math.max(0, subtotal - discountAmount);

  const handleApplyCoupon = async () => {
    if (!couponCode) return;
    try {
      const res = await validateMutation.mutateAsync(couponCode);
      if (res.valid && res.coupon) {
        setAppliedCoupon(res.coupon);
        toast({ title: "تم تطبيق الكوبون بنجاح" });
      } else {
        toast({ title: "كوبون غير صالح", description: res.message, variant: "destructive" });
        setAppliedCoupon(null);
      }
    } catch (e) {
      toast({ title: "خطأ في التحقق من الكوبون", variant: "destructive" });
    }
  };

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createOrderMutation.mutateAsync({
        items: items.map(i => ({ productId: i.product.id, quantity: i.quantity })),
        couponCode: appliedCoupon?.code,
      });
      setLocation("/dashboard");
    } catch (e) {
      // Error handled in hook
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
      <h1 className="text-4xl font-display font-bold mb-12 text-center">إتمام الدفع</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
        
        {/* Form */}
        <div className="bg-card p-8 rounded-3xl border border-border/50 shadow-sm">
          <h2 className="text-2xl font-bold mb-8">معلومات التوصيل</h2>
          <form id="checkout-form" onSubmit={handleCheckout} className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold mb-2">الاسم الأول</label>
                <input required type="text" className="w-full px-4 py-3 bg-muted border-none rounded-xl focus:ring-2 focus:ring-primary outline-none" />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">العائلة</label>
                <input required type="text" className="w-full px-4 py-3 bg-muted border-none rounded-xl focus:ring-2 focus:ring-primary outline-none" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold mb-2">العنوان</label>
              <input required type="text" className="w-full px-4 py-3 bg-muted border-none rounded-xl focus:ring-2 focus:ring-primary outline-none" />
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold mb-2">المدينة</label>
                <input required type="text" className="w-full px-4 py-3 bg-muted border-none rounded-xl focus:ring-2 focus:ring-primary outline-none" />
              </div>
              <div>
                <label className="block text-sm font-semibold mb-2">رقم الهاتف</label>
                <input required type="tel" className="w-full px-4 py-3 bg-muted border-none rounded-xl focus:ring-2 focus:ring-primary outline-none" />
              </div>
            </div>
            
            <h2 className="text-2xl font-bold mt-12 mb-6">الدفع</h2>
            <div className="p-4 border-2 border-primary/20 bg-primary/5 rounded-xl text-center text-primary font-bold">
              الدفع عند الاستلام (للتجربة فقط)
            </div>
          </form>
        </div>

        {/* Order Summary */}
        <div className="space-y-8">
          <div className="bg-card p-8 rounded-3xl border border-border/50 shadow-sm">
            <h2 className="text-2xl font-bold mb-8">الطلب</h2>
            
            <div className="space-y-4 mb-8">
              {items.map(item => (
                <div key={item.product.id} className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-muted overflow-hidden flex-shrink-0">
                    {item.product.imageUrl && <img src={item.product.imageUrl} className="w-full h-full object-cover" />}
                  </div>
                  <div className="flex-1">
                    <p className="font-bold line-clamp-1">{item.product.name}</p>
                    <p className="text-sm text-muted-foreground">الكمية: {item.quantity}</p>
                  </div>
                  <div className="font-bold text-primary">
                    {formatPrice(item.product.price * item.quantity)}
                  </div>
                </div>
              ))}
            </div>

            <div className="h-px bg-border w-full mb-8" />

            {/* Coupon */}
            <div className="mb-8">
              <label className="block text-sm font-semibold mb-2">كوبون الخصم</label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Ticket className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <input 
                    type="text" 
                    value={couponCode}
                    onChange={e => setCouponCode(e.target.value)}
                    disabled={!!appliedCoupon}
                    className="w-full pl-4 pr-12 py-3 bg-muted border-none rounded-xl focus:ring-2 focus:ring-primary outline-none disabled:opacity-50"
                  />
                </div>
                {appliedCoupon ? (
                  <button onClick={() => { setAppliedCoupon(null); setCouponCode(""); }} className="px-6 py-3 bg-destructive text-destructive-foreground rounded-xl font-bold">
                    إلغاء
                  </button>
                ) : (
                  <button onClick={handleApplyCoupon} disabled={validateMutation.isPending || !couponCode} className="px-6 py-3 bg-secondary text-secondary-foreground hover:bg-secondary/80 rounded-xl font-bold disabled:opacity-50 flex items-center justify-center min-w-[100px]">
                    {validateMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : "تطبيق"}
                  </button>
                )}
              </div>
            </div>

            <div className="space-y-4 text-lg">
              <div className="flex justify-between text-muted-foreground">
                <span>المجموع الفرعي</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              {appliedCoupon && (
                <div className="flex justify-between text-emerald-500 font-bold">
                  <span>الخصم ({appliedCoupon.code})</span>
                  <span>- {formatPrice(discountAmount)}</span>
                </div>
              )}
              <div className="flex justify-between text-muted-foreground">
                <span>الشحن</span>
                <span>مجاني</span>
              </div>
              <div className="h-px bg-border w-full my-4" />
              <div className="flex justify-between text-2xl font-display font-bold">
                <span>الإجمالي</span>
                <span className="text-primary">{formatPrice(total)}</span>
              </div>
            </div>
          </div>

          <button 
            type="submit" 
            form="checkout-form"
            disabled={createOrderMutation.isPending}
            className="w-full py-5 bg-primary text-primary-foreground rounded-3xl font-display font-bold text-2xl shadow-xl shadow-primary/25 hover:shadow-2xl hover:shadow-primary/30 hover:-translate-y-1 transition-all disabled:opacity-50 flex items-center justify-center gap-3"
          >
            {createOrderMutation.isPending ? <Loader2 className="w-8 h-8 animate-spin" /> : "تأكيد الطلب"}
          </button>
        </div>

      </div>
    </div>
  );
}

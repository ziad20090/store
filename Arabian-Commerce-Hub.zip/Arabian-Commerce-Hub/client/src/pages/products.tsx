import { useState } from "react";
import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/product/ProductCard";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ProductsPage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  
  // Debounce search in a real app, keeping simple here
  const { data: products, isLoading } = useProducts({
    ...(search && { search }),
    ...(category && { category }),
  });

  const categories = ["كل المنتجات", "إلكترونيات", "أزياء", "منزل", "عطور"];

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-display font-bold text-foreground mb-4">المتجر</h1>
          <p className="text-muted-foreground">تسوق من أفضل تشكيلة منتجات مصممة خصيصاً لك.</p>
        </div>

        <div className="w-full md:w-auto flex items-center gap-4">
          <div className="relative flex-1 md:w-72">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input 
              type="text" 
              placeholder="ابحث عن..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-4 pr-12 py-3 rounded-2xl bg-card border border-border focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none"
            />
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className="p-3 bg-card border border-border rounded-2xl text-foreground hover:bg-muted transition-colors"
          >
            <SlidersHorizontal className="w-6 h-6" />
          </button>
        </div>
      </div>

      <AnimatePresence>
        {showFilters && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden mb-12"
          >
            <div className="p-6 bg-card border border-border/50 rounded-3xl flex flex-wrap gap-4 items-center">
              <span className="font-bold text-foreground ml-4">التصنيفات:</span>
              {categories.map(c => (
                <button
                  key={c}
                  onClick={() => setCategory(c === "كل المنتجات" ? "" : c)}
                  className={`px-6 py-2 rounded-full text-sm font-semibold transition-all ${
                    (category === c) || (category === "" && c === "كل المنتجات")
                      ? "bg-primary text-primary-foreground shadow-md shadow-primary/25"
                      : "bg-muted text-muted-foreground hover:bg-secondary hover:text-foreground"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {[1,2,3,4,5,6,7,8].map(i => (
            <div key={i} className="animate-pulse bg-muted rounded-3xl aspect-[3/4]" />
          ))}
        </div>
      ) : products?.length === 0 ? (
        <div className="py-32 flex flex-col items-center justify-center text-center">
          <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-6">
            <Search className="w-10 h-10 text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-bold mb-2">لم نتمكن من إيجاد ما تبحث عنه</h2>
          <p className="text-muted-foreground mb-8">حاول استخدام كلمات مفتاحية مختلفة أو إزالة الفلاتر</p>
          <button 
            onClick={() => { setSearch(""); setCategory(""); }}
            className="px-8 py-3 bg-primary text-primary-foreground rounded-xl font-bold"
          >
            مسح الفلاتر
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products?.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}

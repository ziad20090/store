import { useAuth } from "@/hooks/use-auth";
import { useOrders } from "@/hooks/use-orders";
import { useLocation } from "wouter";
import { formatPrice } from "@/lib/utils";
import { format } from "date-fns";
import { Package, User as UserIcon } from "lucide-react";

export default function DashboardPage() {
  const { user, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { data: orders, isLoading: ordersLoading } = useOrders();

  if (authLoading) return <div className="min-h-[60vh] flex items-center justify-center"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"/></div>;
  if (!user) {
    setLocation("/auth");
    return null;
  }

  const translateStatus = (status: string) => {
    switch(status) {
      case 'pending': return 'قيد المراجعة';
      case 'completed': return 'مكتمل';
      case 'cancelled': return 'ملغي';
      default: return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'pending': return 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20';
      case 'completed': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
      case 'cancelled': return 'bg-red-500/10 text-red-600 border-red-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center gap-6 mb-12 bg-card p-8 rounded-3xl border border-border/50">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center">
          <UserIcon className="w-10 h-10 text-primary" />
        </div>
        <div>
          <h1 className="text-3xl font-display font-bold mb-2">مرحباً، {user.username}</h1>
          <p className="text-muted-foreground">تتبع طلباتك وإدارة حسابك من هنا.</p>
        </div>
      </div>

      <h2 className="text-2xl font-display font-bold mb-8 flex items-center gap-3">
        <Package className="w-6 h-6 text-primary" />
        تاريخ الطلبات
      </h2>

      {ordersLoading ? (
        <div className="space-y-4">
          {[1,2].map(i => <div key={i} className="h-32 bg-muted animate-pulse rounded-2xl" />)}
        </div>
      ) : orders?.length === 0 ? (
        <div className="text-center py-20 bg-card rounded-3xl border border-border/50">
          <p className="text-muted-foreground text-lg mb-4">ليس لديك أي طلبات سابقة.</p>
        </div>
      ) : (
        <div className="grid gap-6">
          {orders?.map(order => (
            <div key={order.id} className="bg-card p-6 sm:p-8 rounded-3xl border border-border/50 flex flex-col md:flex-row justify-between gap-8 hover:shadow-lg transition-shadow">
              
              <div className="flex-1 space-y-4">
                <div className="flex flex-wrap items-center gap-4">
                  <h3 className="font-bold text-lg">طلب #{order.id}</h3>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold border ${getStatusColor(order.status)}`}>
                    {translateStatus(order.status)}
                  </span>
                  <span className="text-muted-foreground text-sm">
                    {order.createdAt ? format(new Date(order.createdAt), "yyyy-MM-dd HH:mm") : ""}
                  </span>
                </div>
                
                <div className="flex flex-wrap gap-4">
                  {order.items.map(item => (
                    <div key={item.id} className="flex items-center gap-3 bg-muted/50 p-2 pr-4 rounded-xl border border-border">
                      <div className="w-12 h-12 rounded-lg overflow-hidden bg-background">
                        {item.product.imageUrl && <img src={item.product.imageUrl} className="w-full h-full object-cover"/>}
                      </div>
                      <div>
                        <p className="text-sm font-bold truncate max-w-[150px]">{item.product.name}</p>
                        <p className="text-xs text-muted-foreground">{item.quantity} x {formatPrice(item.priceAtTime)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="md:w-48 flex flex-col justify-center items-start md:items-end border-t md:border-t-0 md:border-r border-border pt-4 md:pt-0 md:pr-8">
                <p className="text-muted-foreground text-sm mb-1">إجمالي الطلب</p>
                <p className="text-2xl font-display font-bold text-primary">{formatPrice(order.totalAmount)}</p>
              </div>

            </div>
          ))}
        </div>
      )}
    </div>
  );
}

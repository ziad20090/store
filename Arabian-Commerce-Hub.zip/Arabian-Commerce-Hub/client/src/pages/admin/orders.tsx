import { useAllOrders, useUpdateOrderStatus } from "@/hooks/use-orders";
import { formatPrice } from "@/lib/utils";
import { format } from "date-fns";
import { ArrowRight, CheckCircle, XCircle } from "lucide-react";
import { Link } from "wouter";

export default function AdminOrders() {
  const { data: orders, isLoading } = useAllOrders();
  const updateStatus = useUpdateOrderStatus();

  const handleUpdate = (id: number, status: string) => {
    updateStatus.mutate({ id, status });
  };

  return (
    <div className="p-6 lg:p-10" dir="rtl">
      <div className="flex items-center gap-4 mb-10">
        <Link href="/admin" className="p-2 bg-muted rounded-full hover:bg-secondary transition-colors"><ArrowRight className="w-5 h-5"/></Link>
        <h1 className="text-3xl font-display font-bold">إدارة الطلبات</h1>
      </div>

      <div className="bg-card rounded-3xl border border-border/50 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-start">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                <th className="p-4 font-bold text-muted-foreground">رقم الطلب</th>
                <th className="p-4 font-bold text-muted-foreground">التاريخ</th>
                <th className="p-4 font-bold text-muted-foreground">الإجمالي</th>
                <th className="p-4 font-bold text-muted-foreground">الحالة</th>
                <th className="p-4 font-bold text-muted-foreground text-end">تغيير الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {orders?.map(o => (
                <tr key={o.id} className="hover:bg-muted/20 transition-colors">
                  <td className="p-4 font-bold">#{o.id}</td>
                  <td className="p-4 text-muted-foreground">{o.createdAt ? format(new Date(o.createdAt), "yyyy-MM-dd") : ""}</td>
                  <td className="p-4 font-bold text-primary">{formatPrice(o.totalAmount)}</td>
                  <td className="p-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold border ${o.status === 'pending' ? 'bg-yellow-500/10 text-yellow-600' : o.status === 'completed' ? 'bg-emerald-500/10 text-emerald-600' : 'bg-red-500/10 text-red-600'}`}>
                      {o.status === 'pending' ? 'قيد المراجعة' : o.status === 'completed' ? 'مكتمل' : 'ملغي'}
                    </span>
                  </td>
                  <td className="p-4 text-end flex justify-end gap-2">
                    {o.status === 'pending' && (
                      <>
                        <button onClick={() => handleUpdate(o.id, 'completed')} className="p-2 bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500 hover:text-white rounded-lg transition-colors" title="إكمال">
                          <CheckCircle className="w-5 h-5" />
                        </button>
                        <button onClick={() => handleUpdate(o.id, 'cancelled')} className="p-2 bg-red-500/10 text-red-600 hover:bg-red-500 hover:text-white rounded-lg transition-colors" title="إلغاء">
                          <XCircle className="w-5 h-5" />
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

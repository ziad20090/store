import { useState } from "react";
import { useProducts, useCreateProduct, useDeleteProduct } from "@/hooks/use-products";
import { formatPrice } from "@/lib/utils";
import { Plus, Trash2, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function AdminProducts() {
  const { data: products, isLoading } = useProducts();
  const createMutation = useCreateProduct();
  const deleteMutation = useDeleteProduct();
  
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "", description: "", price: 0, stock: 0, category: "", imageUrl: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createMutation.mutateAsync(formData);
    setIsFormOpen(false);
    setFormData({ name: "", description: "", price: 0, stock: 0, category: "", imageUrl: "" });
  };

  return (
    <div className="p-6 lg:p-10" dir="rtl">
      <div className="flex justify-between items-center mb-10">
        <div className="flex items-center gap-4">
          <Link href="/admin" className="p-2 bg-muted rounded-full hover:bg-secondary transition-colors"><ArrowRight className="w-5 h-5"/></Link>
          <h1 className="text-3xl font-display font-bold">إدارة المنتجات</h1>
        </div>
        <button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-bold rounded-xl shadow-lg hover:shadow-xl transition-all">
          <Plus className="w-5 h-5" /> إضافة منتج
        </button>
      </div>

      {isFormOpen && (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card p-8 rounded-3xl border border-border w-full max-w-2xl shadow-2xl">
            <h2 className="text-2xl font-bold mb-6">منتج جديد</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-1 font-bold">الاسم</label>
                  <input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full p-3 bg-muted rounded-xl" />
                </div>
                <div>
                  <label className="block text-sm mb-1 font-bold">التصنيف</label>
                  <input required value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="w-full p-3 bg-muted rounded-xl" />
                </div>
                <div>
                  <label className="block text-sm mb-1 font-bold">السعر (بالهللات)</label>
                  <input required type="number" value={formData.price || ''} onChange={e => setFormData({...formData, price: parseInt(e.target.value)})} className="w-full p-3 bg-muted rounded-xl" />
                </div>
                <div>
                  <label className="block text-sm mb-1 font-bold">المخزون</label>
                  <input required type="number" value={formData.stock || ''} onChange={e => setFormData({...formData, stock: parseInt(e.target.value)})} className="w-full p-3 bg-muted rounded-xl" />
                </div>
              </div>
              <div>
                <label className="block text-sm mb-1 font-bold">الوصف</label>
                <textarea required value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full p-3 bg-muted rounded-xl h-24 resize-none" />
              </div>
              <div>
                <label className="block text-sm mb-1 font-bold">رابط الصورة</label>
                <input value={formData.imageUrl} onChange={e => setFormData({...formData, imageUrl: e.target.value})} className="w-full p-3 bg-muted rounded-xl" />
              </div>
              <div className="flex gap-4 mt-8">
                <button type="submit" disabled={createMutation.isPending} className="flex-1 bg-primary text-primary-foreground py-3 rounded-xl font-bold">حفظ</button>
                <button type="button" onClick={() => setIsFormOpen(false)} className="px-6 bg-muted rounded-xl font-bold">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-card rounded-3xl border border-border/50 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-start">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                <th className="p-4 font-bold text-muted-foreground">المنتج</th>
                <th className="p-4 font-bold text-muted-foreground">السعر</th>
                <th className="p-4 font-bold text-muted-foreground">المخزون</th>
                <th className="p-4 font-bold text-muted-foreground">التصنيف</th>
                <th className="p-4 font-bold text-muted-foreground text-end">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {products?.map(p => (
                <tr key={p.id} className="hover:bg-muted/20 transition-colors">
                  <td className="p-4 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-muted overflow-hidden">
                      {p.imageUrl && <img src={p.imageUrl} className="w-full h-full object-cover"/>}
                    </div>
                    <span className="font-bold">{p.name}</span>
                  </td>
                  <td className="p-4 text-primary font-bold">{formatPrice(p.price)}</td>
                  <td className="p-4">{p.stock}</td>
                  <td className="p-4"><span className="px-3 py-1 bg-secondary text-secondary-foreground rounded-full text-xs font-bold">{p.category}</span></td>
                  <td className="p-4 text-end">
                    <button onClick={() => deleteMutation.mutate(p.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

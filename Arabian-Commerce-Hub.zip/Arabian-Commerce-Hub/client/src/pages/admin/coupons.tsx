import { useState } from "react";
import { useCoupons, useCreateCoupon, useDeleteCoupon } from "@/hooks/use-coupons";
import { Plus, Trash2, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function AdminCoupons() {
  const { data: coupons } = useCoupons();
  const createMutation = useCreateCoupon();
  const deleteMutation = useDeleteCoupon();
  
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [formData, setFormData] = useState({
    code: "", discountType: "percent", discountValue: 10, usageLimit: 0
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createMutation.mutateAsync(formData);
    setIsFormOpen(false);
    setFormData({ code: "", discountType: "percent", discountValue: 10, usageLimit: 0 });
  };

  return (
    <div className="p-6 lg:p-10" dir="rtl">
      <div className="flex justify-between items-center mb-10">
        <div className="flex items-center gap-4">
          <Link href="/admin" className="p-2 bg-muted rounded-full hover:bg-secondary transition-colors"><ArrowRight className="w-5 h-5"/></Link>
          <h1 className="text-3xl font-display font-bold">إدارة الكوبونات</h1>
        </div>
        <button onClick={() => setIsFormOpen(true)} className="flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-bold rounded-xl shadow-lg hover:shadow-xl transition-all">
          <Plus className="w-5 h-5" /> إضافة كوبون
        </button>
      </div>

      {isFormOpen && (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card p-8 rounded-3xl border border-border w-full max-w-md shadow-2xl">
            <h2 className="text-2xl font-bold mb-6">كوبون جديد</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm mb-1 font-bold">الرمز (Code)</label>
                <input required value={formData.code} onChange={e => setFormData({...formData, code: e.target.value.toUpperCase()})} className="w-full p-3 bg-muted rounded-xl uppercase" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-1 font-bold">النوع</label>
                  <select value={formData.discountType} onChange={e => setFormData({...formData, discountType: e.target.value})} className="w-full p-3 bg-muted rounded-xl outline-none">
                    <option value="percent">نسبة (%)</option>
                    <option value="fixed">مبلغ ثابت</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm mb-1 font-bold">القيمة</label>
                  <input required type="number" value={formData.discountValue || ''} onChange={e => setFormData({...formData, discountValue: parseInt(e.target.value)})} className="w-full p-3 bg-muted rounded-xl" />
                </div>
              </div>
              <div>
                <label className="block text-sm mb-1 font-bold">حد الاستخدام (0 = غير محدود)</label>
                <input required type="number" value={formData.usageLimit} onChange={e => setFormData({...formData, usageLimit: parseInt(e.target.value)})} className="w-full p-3 bg-muted rounded-xl" />
              </div>
              
              <div className="flex gap-4 mt-8">
                <button type="submit" disabled={createMutation.isPending} className="flex-1 bg-primary text-primary-foreground py-3 rounded-xl font-bold">حفظ</button>
                <button type="button" onClick={() => setIsFormOpen(false)} className="px-6 bg-muted rounded-xl font-bold">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-card rounded-3xl border border-border/50 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-start">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                <th className="p-4 font-bold text-muted-foreground">الرمز</th>
                <th className="p-4 font-bold text-muted-foreground">الخصم</th>
                <th className="p-4 font-bold text-muted-foreground">الاستخدام</th>
                <th className="p-4 font-bold text-muted-foreground text-end">حذف</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {coupons?.map(c => (
                <tr key={c.id} className="hover:bg-muted/20 transition-colors">
                  <td className="p-4 font-bold text-lg tracking-widest">{c.code}</td>
                  <td className="p-4 text-emerald-500 font-bold">{c.discountValue}{c.discountType === 'percent' ? '%' : ' SAR'}</td>
                  <td className="p-4">{c.usageCount} / {c.usageLimit === 0 ? '∞' : c.usageLimit}</td>
                  <td className="p-4 text-end">
                    <button onClick={() => deleteMutation.mutate(c.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

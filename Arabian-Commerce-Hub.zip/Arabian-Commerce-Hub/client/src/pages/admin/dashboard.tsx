import { useAnalytics } from "@/hooks/use-analytics";
import { formatPrice } from "@/lib/utils";
import { Link } from "wouter";
import { Package, Ticket, ShoppingCart, DollarSign, Users, AlertTriangle, ArrowRight } from "lucide-react";

export default function AdminDashboard() {
  const { data: analytics, isLoading } = useAnalytics();

  if (isLoading) return <div className="p-8 animate-pulse text-center">جاري التحميل...</div>;

  const stats = [
    { label: "إجمالي المبيعات", value: formatPrice(analytics?.totalSales || 0), icon: DollarSign, color: "text-emerald-500", bg: "bg-emerald-500/10" },
    { label: "إجمالي الطلبات", value: analytics?.totalOrders || 0, icon: ShoppingCart, color: "text-blue-500", bg: "bg-blue-500/10" },
    { label: "المستخدمين المسجلين", value: analytics?.totalUsers || 0, icon: Users, color: "text-purple-500", bg: "bg-purple-500/10" },
  ];

  return (
    <div className="p-6 lg:p-10" dir="rtl">
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-4xl font-display font-bold mb-2">لوحة التحكم</h1>
          <p className="text-muted-foreground">نظرة عامة على أداء المتجر</p>
        </div>
        <Link href="/" className="flex items-center gap-2 px-4 py-2 bg-muted text-foreground rounded-xl hover:bg-secondary transition-colors font-bold">
          العودة للمتجر <ArrowRight className="w-4 h-4" />
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {stats.map((stat, i) => (
          <div key={i} className="bg-card p-6 rounded-3xl border border-border/50 shadow-sm flex items-center gap-6">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${stat.bg}`}>
              <stat.icon className={`w-8 h-8 ${stat.color}`} />
            </div>
            <div>
              <p className="text-muted-foreground font-semibold mb-1">{stat.label}</p>
              <p className="text-3xl font-display font-bold">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-card p-8 rounded-3xl border border-border/50 shadow-sm">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-yellow-500" />
            منتجات توشك على النفاذ
          </h2>
          <div className="space-y-4">
            {analytics?.lowStockProducts?.map(p => (
              <div key={p.id} className="flex justify-between items-center p-4 bg-muted/50 rounded-xl border border-border">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-background overflow-hidden">
                    {p.imageUrl && <img src={p.imageUrl} className="w-full h-full object-cover" />}
                  </div>
                  <p className="font-bold">{p.name}</p>
                </div>
                <div className="px-4 py-1 bg-destructive/10 text-destructive rounded-full font-bold text-sm">
                  متبقي {p.stock} فقط
                </div>
              </div>
            ))}
            {(!analytics?.lowStockProducts || analytics.lowStockProducts.length === 0) && (
              <p className="text-muted-foreground text-center py-4">المخزون ممتاز، لا يوجد منتجات ناقصة.</p>
            )}
          </div>
        </div>

        <div className="bg-card p-8 rounded-3xl border border-border/50 shadow-sm">
          <h2 className="text-xl font-bold mb-6">الإدارة السريعة</h2>
          <div className="grid grid-cols-2 gap-4">
            <Link href="/admin/products" className="p-6 bg-muted hover:bg-primary/10 hover:text-primary rounded-2xl border border-border transition-colors flex flex-col items-center justify-center gap-3 text-center group">
              <Package className="w-8 h-8 text-muted-foreground group-hover:text-primary" />
              <span className="font-bold">إدارة المنتجات</span>
            </Link>
            <Link href="/admin/orders" className="p-6 bg-muted hover:bg-primary/10 hover:text-primary rounded-2xl border border-border transition-colors flex flex-col items-center justify-center gap-3 text-center group">
              <ShoppingCart className="w-8 h-8 text-muted-foreground group-hover:text-primary" />
              <span className="font-bold">إدارة الطلبات</span>
            </Link>
            <Link href="/admin/coupons" className="p-6 bg-muted hover:bg-primary/10 hover:text-primary rounded-2xl border border-border transition-colors flex flex-col items-center justify-center gap-3 text-center group">
              <Ticket className="w-8 h-8 text-muted-foreground group-hover:text-primary" />
              <span className="font-bold">الكوبونات</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

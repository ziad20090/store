import { useRoute } from "wouter";
import { useProduct } from "@/hooks/use-products";
import { formatPrice } from "@/lib/utils";
import { useCart } from "@/store/use-cart";
import { useToggleWishlist, useWishlist } from "@/hooks/use-wishlist";
import { useState } from "react";
import { Minus, Plus, ShoppingBag, Heart, ShieldCheck, Truck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ProductDetails() {
  const [, params] = useRoute("/product/:id");
  const id = Number(params?.id);
  const { data: product, isLoading } = useProduct(id);
  
  const [quantity, setQuantity] = useState(1);
  const addItem = useCart(state => state.addItem);
  const { toggle } = useToggleWishlist();
  const { data: wishlist } = useWishlist();
  const { toast } = useToast();

  if (isLoading) return <div className="container mx-auto px-4 py-24 animate-pulse bg-muted h-[60vh] rounded-3xl" />;
  if (!product) return <div className="container mx-auto px-4 py-24 text-center text-2xl font-bold">المنتج غير موجود</div>;

  const isFav = wishlist?.some(item => item.productId === product.id);

  const handleAddToCart = () => {
    addItem(product, quantity);
    toast({ title: "تمت الإضافة", description: `تمت إضافة ${quantity} من ${product.name} إلى السلة` });
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-24">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
        {/* Images */}
        <div className="relative aspect-[4/5] rounded-[3rem] overflow-hidden bg-muted border border-border">
          {product.imageUrl ? (
            <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-2xl text-muted-foreground font-display">لا توجد صورة</div>
          )}
        </div>

        {/* Details */}
        <div className="flex flex-col justify-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary text-secondary-foreground font-semibold text-sm mb-6 self-start">
            {product.category}
          </div>
          
          <h1 className="text-4xl lg:text-5xl font-display font-bold text-foreground mb-4 leading-tight">
            {product.name}
          </h1>
          
          <p className="text-3xl font-display font-bold text-primary mb-8">
            {formatPrice(product.price)}
          </p>

          <p className="text-lg text-muted-foreground mb-10 leading-relaxed">
            {product.description}
          </p>

          <div className="h-px bg-border w-full mb-10" />

          {/* Add to cart section */}
          <div className="flex flex-col sm:flex-row gap-6 mb-10">
            <div className="flex items-center justify-between bg-card border border-border rounded-2xl p-2 w-full sm:w-40">
              <button 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-muted text-foreground transition-colors"
              >
                <Minus className="w-5 h-5" />
              </button>
              <span className="font-bold text-xl w-10 text-center">{quantity}</span>
              <button 
                onClick={() => setQuantity(quantity + 1)}
                className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-muted text-foreground transition-colors"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>

            <button 
              onClick={handleAddToCart}
              disabled={product.stock === 0}
              className="flex-1 bg-primary text-primary-foreground py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-3 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-1 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ShoppingBag className="w-6 h-6" />
              {product.stock === 0 ? "نفدت الكمية" : "أضف للسلة"}
            </button>

            <button 
              onClick={() => toggle(product.id)}
              className={`w-16 h-16 flex items-center justify-center rounded-2xl border transition-all ${
                isFav 
                  ? 'bg-primary/10 border-primary text-primary' 
                  : 'bg-card border-border text-muted-foreground hover:border-primary hover:text-primary'
              }`}
            >
              <Heart className={`w-6 h-6 ${isFav ? 'fill-current' : ''}`} />
            </button>
          </div>

          {/* Features */}
          <div className="grid grid-cols-2 gap-6">
            <div className="flex items-center gap-4 bg-muted/50 p-4 rounded-2xl">
              <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center shadow-sm">
                <Truck className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-bold text-sm">شحن مجاني</p>
                <p className="text-xs text-muted-foreground">للطلبات فوق 500 ريال</p>
              </div>
            </div>
            <div className="flex items-center gap-4 bg-muted/50 p-4 rounded-2xl">
              <div className="w-12 h-12 bg-background rounded-full flex items-center justify-center shadow-sm">
                <ShieldCheck className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="font-bold text-sm">ضمان الجودة</p>
                <p className="text-xs text-muted-foreground">منتج أصلي 100%</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/product/ProductCard";
import { motion } from "framer-motion";
import { ArrowLeft, Star, Zap, ShieldCheck } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { data: products, isLoading } = useProducts();
  const featuredProducts = products?.slice(0, 4) || [];

  return (
    <div className="flex flex-col gap-24 pb-24">
      {/* Hero Section */}
      <section className="relative pt-12 pb-20 lg:pt-24 lg:pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-background z-[-1]" />
        
        {/* Decorative elements */}
        <div className="absolute top-20 right-10 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-accent/50 rounded-full blur-3xl" />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-2xl"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-semibold text-sm mb-6 border border-primary/20">
                <Star className="w-4 h-4 fill-current" />
                تشكيلة الموسم الجديد متوفرة الآن
              </div>
              <h1 className="text-5xl lg:text-7xl font-display font-bold text-foreground leading-[1.1] mb-6">
                ارتقِ بمظهرك مع <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-teal-400">أرقى</span> التصاميم
              </h1>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                اكتشف مجموعتنا الحصرية من الأزياء والمنتجات الفاخرة التي تعكس ذوقك الرفيع. تسوق الآن واستمتع بتجربة فريدة.
              </p>
              <div className="flex flex-wrap items-center gap-4">
                <Link href="/shop" className="px-8 py-4 rounded-2xl bg-primary text-primary-foreground font-bold text-lg shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-1 transition-all duration-300">
                  تسوق الآن
                </Link>
                <Link href="/categories" className="px-8 py-4 rounded-2xl bg-secondary text-secondary-foreground font-bold text-lg hover:bg-secondary/80 transition-all duration-300 border border-border">
                  تصفح الأقسام
                </Link>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              {/* home page hero fashion model minimal */}
              <img 
                src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800&h=1000&fit=crop" 
                alt="أزياء فاخرة" 
                className="rounded-[2.5rem] shadow-2xl object-cover aspect-[4/5] w-full max-w-md mx-auto relative z-10 border-8 border-background"
              />
              <div className="absolute -bottom-6 -left-6 bg-card p-6 rounded-3xl shadow-xl border border-border/50 z-20 animate-bounce" style={{ animationDuration: '3s' }}>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <Zap className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground font-semibold">توصيل سريع</p>
                    <p className="text-sm font-bold text-foreground">خلال 24 ساعة</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { icon: ShieldCheck, title: "جودة مضمونة", desc: "منتجات أصلية 100% مع ضمان الجودة" },
            { icon: Zap, title: "شحن سريع", desc: "توصيل مجاني للطلبات فوق 500 ريال" },
            { icon: Star, title: "دعم على مدار الساعة", desc: "فريق خدمة العملاء جاهز لخدمتك" }
          ].map((feature, idx) => (
            <div key={idx} className="bg-card p-8 rounded-3xl border border-border/50 flex flex-col items-center text-center hover:shadow-lg transition-all duration-300">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
                <feature.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="font-bold text-xl mb-3">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">الأكثر مبيعاً</h2>
            <p className="text-muted-foreground">اكتشف المنتجات المفضلة لدى عملائنا</p>
          </div>
          <Link href="/shop" className="hidden sm:flex items-center gap-2 text-primary font-bold hover:gap-3 transition-all">
            عرض الكل <ArrowLeft className="w-5 h-5" />
          </Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[1,2,3,4].map(i => (
              <div key={i} className="animate-pulse bg-muted rounded-3xl aspect-[3/4]" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
        
        <Link href="/shop" className="sm:hidden flex items-center justify-center gap-2 text-primary font-bold mt-8 p-4 bg-primary/5 rounded-2xl">
          عرض الكل <ArrowLeft className="w-5 h-5" />
        </Link>
      </section>
    </div>
  );
}

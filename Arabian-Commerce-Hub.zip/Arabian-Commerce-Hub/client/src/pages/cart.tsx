import { Link, useLocation } from "wouter";
import { useCart } from "@/store/use-cart";
import { formatPrice } from "@/lib/utils";
import { Minus, Plus, Trash2, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export default function CartPage() {
  const { items, updateQuantity, removeItem, getSubtotal } = useCart();
  const [, setLocation] = useLocation();

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-32 flex flex-col items-center justify-center text-center">
        <div className="w-32 h-32 bg-primary/5 rounded-full flex items-center justify-center mb-8">
          <ShoppingCart className="w-16 h-16 text-primary opacity-50" />
        </div>
        <h1 className="text-4xl font-display font-bold mb-4">السلة فارغة</h1>
        <p className="text-muted-foreground mb-8 text-lg">لم تقم بإضافة أي منتجات للسلة بعد.</p>
        <Link href="/shop" className="px-8 py-4 bg-primary text-primary-foreground rounded-2xl font-bold text-lg hover:shadow-lg hover:shadow-primary/30 transition-all">
          العودة للتسوق
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
      <h1 className="text-4xl font-display font-bold mb-12">عربة التسوق</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Items List */}
        <div className="lg:col-span-2 space-y-6">
          {items.map((item) => (
            <motion.div 
              key={item.product.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex flex-col sm:flex-row items-center gap-6 p-6 bg-card rounded-3xl border border-border/50 shadow-sm"
            >
              <div className="w-full sm:w-32 aspect-square rounded-2xl overflow-hidden bg-muted flex-shrink-0">
                {item.product.imageUrl ? (
                  <img src={item.product.imageUrl} alt={item.product.name} className="w-full h-full object-cover" />
                ) : null}
              </div>
              
              <div className="flex-1 text-center sm:text-start">
                <Link href={`/product/${item.product.id}`} className="text-xl font-bold hover:text-primary transition-colors block mb-2">
                  {item.product.name}
                </Link>
                <p className="text-muted-foreground text-sm mb-4">{item.product.category}</p>
                <p className="text-lg font-bold text-primary">{formatPrice(item.product.price)}</p>
              </div>

              <div className="flex items-center gap-6">
                <div className="flex items-center bg-muted rounded-xl p-1">
                  <button onClick={() => updateQuantity(item.product.id, item.quantity - 1)} className="w-8 h-8 flex items-center justify-center hover:bg-background rounded-lg transition-colors">
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-10 text-center font-bold">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.product.id, item.quantity + 1)} className="w-8 h-8 flex items-center justify-center hover:bg-background rounded-lg transition-colors">
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                
                <button 
                  onClick={() => removeItem(item.product.id)}
                  className="w-10 h-10 flex items-center justify-center rounded-xl bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground transition-colors"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Summary */}
        <div className="lg:col-span-1">
          <div className="bg-card rounded-3xl border border-border/50 shadow-sm p-8 sticky top-32">
            <h2 className="text-2xl font-bold mb-8">ملخص الطلب</h2>
            
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-muted-foreground">
                <span>المجموع الفرعي</span>
                <span>{formatPrice(getSubtotal())}</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>الشحن</span>
                <span>مجاني</span>
              </div>
              <div className="h-px bg-border w-full my-4" />
              <div className="flex justify-between text-xl font-display font-bold">
                <span>الإجمالي</span>
                <span className="text-primary">{formatPrice(getSubtotal())}</span>
              </div>
            </div>

            <button 
              onClick={() => setLocation("/checkout")}
              className="w-full py-4 bg-primary text-primary-foreground rounded-2xl font-bold text-lg hover:shadow-lg hover:shadow-primary/30 hover:-translate-y-1 transition-all flex items-center justify-center gap-2"
            >
              متابعة الدفع
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Temporary icon since we didn't import it at the top
import { ShoppingCart } from "lucide-react";

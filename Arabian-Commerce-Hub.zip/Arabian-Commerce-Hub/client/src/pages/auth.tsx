import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const { login, register, isLoggingIn, isRegistering, user } = useAuth();
  const [, setLocation] = useLocation();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  if (user) {
    setLocation("/dashboard");
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLogin) {
      await login({ username, password });
    } else {
      await register({ username, password });
    }
  };

  const isPending = isLoggingIn || isRegistering;

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-card p-8 sm:p-12 rounded-[2.5rem] border border-border/50 shadow-2xl shadow-black/5"
      >
        <div className="text-center mb-10">
          <h1 className="text-3xl font-display font-bold text-foreground mb-2">
            {isLogin ? "مرحباً بك مجدداً" : "إنشاء حساب جديد"}
          </h1>
          <p className="text-muted-foreground">
            {isLogin ? "سجل دخولك لمتابعة التسوق" : "انضم إلينا واستمتع بتجربة تسوق فريدة"}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold mb-2">اسم المستخدم</label>
            <input 
              required
              type="text" 
              value={username}
              onChange={e => setUsername(e.target.value)}
              className="w-full px-5 py-4 bg-muted border border-transparent focus:border-primary focus:ring-4 focus:ring-primary/10 rounded-2xl outline-none transition-all"
              placeholder="admin أو user"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2">كلمة المرور</label>
            <input 
              required
              type="password" 
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full px-5 py-4 bg-muted border border-transparent focus:border-primary focus:ring-4 focus:ring-primary/10 rounded-2xl outline-none transition-all"
            />
          </div>

          <button 
            type="submit"
            disabled={isPending}
            className="w-full py-4 bg-primary text-primary-foreground rounded-2xl font-bold text-lg shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 transition-all disabled:opacity-50 flex justify-center"
          >
            {isPending ? <Loader2 className="w-6 h-6 animate-spin" /> : (isLogin ? "دخول" : "تسجيل")}
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-muted-foreground">
            {isLogin ? "ليس لديك حساب؟ " : "لديك حساب بالفعل؟ "}
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="text-primary font-bold hover:underline"
            >
              {isLogin ? "سجل الآن" : "سجل الدخول"}
            </button>
          </p>
        </div>
        <div className="mt-8 p-6 bg-muted/50 rounded-2xl border border-border/50 text-right" dir="rtl">
          <h3 className="font-bold mb-2">بيانات الدخول التجريبية:</h3>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li><strong>مدير النظام:</strong> admin / admin123</li>
            <li><strong>مستخدم عادي:</strong> user / user123</li>
          </ul>
        </div>
      </motion.div>
    </div>
  );
}

## Packages
zustand | Client-side state management for cart
date-fns | Formatting dates in order history
recharts | Admin dashboard charts
clsx | Classname utility
tailwind-merge | Tailwind class merging

## Notes
RTL layout is handled via a global wrapper and logical tailwind properties (e.g. ps-4, ms-4).
Prices are stored in cents on the backend and formatted to localized currency (SAR) on the frontend.
